puts "Setting up for windows"


system("gem install --local alignment_ext-1.0.0.gem")

puts "Done, hit any key to finish."
STDIN.gets
